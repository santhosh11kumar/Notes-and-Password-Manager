import mongoose from "mongoose";
import { credentialSchema } from "./credential.model.js";

const websiteSchema = new mongoose.Schema(
    {
        websiteName: {
            type: String,
            required: true,
            trim: true
        },
        credentials: [credentialSchema]
    },
    {
        timestamps: true
    }
);

export const Website = mongoose.model('Website', websiteSchema);
